from pyspark.sql import SparkSession
from pyspark.sql.types import StructType,StructField, StringType, LongType
from pyspark.sql.functions import col,count, countDistinct, min, max, when, sum, lit, coalesce, array, array_compact, size
from connection_formation import conn_parms
from configparser import ConfigParser
import pandas as pd
import numpy as np
from tabulate import tabulate
from datetime import datetime, timedelta
import time
import logging
from os import path
import os


#logger = logging.getLogger(__name__)
#logging.basicConfig(filename='test.log',encoding='utf-8',level=logging.INFO, format='%(asctime)s %(message)s', datefmt='%m/%d/%Y %I:%M:%S %p')
#logging.info('process started...')

def create_spark_session(SparkSession, spark_jars):
    spark = SparkSession.builder \
        .master("local")\
        .appName("Data Diff") \
        .config('spark.jars', spark_jars)\
        .getOrCreate()
    return spark

def read_data(spark, parser, sql, conn_name):
    # Reading Source Information
    try:
        read_format = parser.get('CONFIG', conn_name.lower()+'_read_format')
        options = conn_parms(parser, conn_name)
        return spark.read.format(read_format) \
            .options(**options) \
            .option("query", sql) \
            .load()
    except Exception as read_error:
        print(read_error)

#describe dataframe
#column_name  min_value, max_value, min_date, max_date, null values, not null values, distinct values, count,  varchar check (sample value)
def describe_table(spark, desc):
    schema= StructType([StructField('column_name', StringType(), True),StructField('data_type', StringType(), True),StructField('min', StringType(), True), StructField('max', StringType(), True), StructField('row_count', LongType(), False), StructField('row_unique_count', LongType(), False), StructField('null_count', LongType(), True)])
    df_desc = spark.createDataFrame(data= spark.sparkContext.emptyRDD(),schema=schema)
    for tbl_col in desc.dtypes:
        df = desc.select(lit(tbl_col[0]).alias('column_name'),lit(tbl_col[1]).alias('data_type'),min(tbl_col[0]).cast('string').alias('min'),max(tbl_col[0]).cast('string').alias('max'),count(lit(1)).alias('row_count'),countDistinct(tbl_col[0]).alias('row_unique_count'),sum(when((col(tbl_col[0]).isNull()) | (col(tbl_col[0].strip()) == ''),1).otherwise(0)).alias('null_count'))
        df_desc = df_desc.union(df)
    df_desc = df_desc.withColumn('notnull_count',col('row_count')-col('null_count'))
    return df_desc


# Record count before and after dropping duplicates
def dups_check(df_check):
    row_count = df_check.count()
    df_distinct_count = df_check.dropDuplicates().count()
    print("Source Table duplication check: ")
    if row_count != df_distinct_count:
        print('Table has {} rows and duplicate rows: {}'.format(row_count, row_count - df_distinct_count))
    else:
        print('Table has {} rows no duplicate rows'.format(row_count))
    print('')

#Checking if the columns we entered make unique or not
def validate_unique_keys(df_check, columns_list):
    df_uk = df_check.dropDuplicates().groupBy(columns_list).agg(count('*').alias('total')).filter(col('total')>1)
    dups = df_uk.count()
    print("Checking if {} the columns are PK of the source table.".format(columns_list))
    if dups > 0:
        print('Unique key has {} duplicates. Please re-assess the columns:'.format(dups))
        print(df_uk.show(truncate=False,n=5))
    else:
        print('Unique key has no duplicates.')
    print('')

def schema_validation(src, tgt):
    try:
        compare_columns = []
        src_schema = pd.DataFrame(src.dtypes, columns=['NAME', 'DATA_TYPE'], dtype=(str, str))
        tgt_schema = pd.DataFrame(tgt.dtypes, columns=['NAME', 'DATA_TYPE'], dtype=(str, str))
        src_schema['NAME'] = src_schema['NAME'].str.lower()
        tgt_schema['NAME'] = tgt_schema['NAME'].str.lower()
        schema_merge = pd.merge(src_schema, tgt_schema, how='outer', on='NAME', suffixes=['_SRC', '_TGT'], indicator=True)
        compare_columns = schema_merge.query("(_merge == 'both')")['NAME'].to_list()
        schema_diff = schema_merge.query("(_merge == 'left_only') | (_merge == 'right_only') | (DATA_TYPE_SRC!=DATA_TYPE_TGT)").reset_index(drop=True)
        conditions = [(schema_diff['_merge'] == 'both'), (schema_diff['_merge'] == 'left_only'), (schema_diff['_merge'] == 'right_only')]
        choice = ['Datatype mismatch', 'Column available only in SRC table', 'Column available only in TGT table']
        schema_diff['COMMENT'] = np.select(conditions, choice)
        schema_diff.drop(columns=['_merge'], inplace=True)
        pd.set_option('display.width', 500)
        print('Schema Validation:')
        if len(schema_diff) == 0:
            print('Schemas matches between Source and Target.')
        else:
            print(schema_diff.to_markdown(index=False, tablefmt='psql'))
        print('')
        return compare_columns
    except Exception as schema_error:
        print(schema_error)


# creates join conditions
# Creates select list
def compare_pre(src_pks, tgt_pks, compare_columns):
    try:
        pk_count = len(src_pks)
        pk_condition = []
        row_ind_src_con = ''
        row_ind_tgt_con = ''
        select_list = []
        column_compare = ''

        for cnt in range(pk_count):
            if cnt == 0:
                row_ind_src_con = 'df_merge.' + src_pks[cnt] + '_src.isNull()'
                row_ind_tgt_con = 'df_merge.' + tgt_pks[cnt] + '_tgt.isNull()'
            else:
                row_ind_src_con = row_ind_src_con + ' & df_merge.' + src_pks[cnt] + '_src.isNull()'
                row_ind_tgt_con = row_ind_tgt_con + ' & df_merge.' + tgt_pks[cnt] + '_tgt.isNull()'
            # pk_columns.append(src_pks[cnt]+'_src')
            #pk_condition.append('src_suffix.' + src_pks[cnt] + '_src.eqNullSafe(tgt_suffix.' + tgt_pks[cnt] + '_tgt)')
            pk_condition.append('col(\'' + src_pks[cnt] + '_src\').eqNullSafe(col(\'' + tgt_pks[cnt] + '_tgt\'))')
            # select_list.append('coalesce('+src_pks[cnt]+'_src,'+tgt_pks[cnt]+'_tgt) as '+src_pks[cnt])
            select_list.append(src_pks[cnt])
        cnt = 0
        for name in compare_columns:
            if not (name in src_pks):
                select_list.append(name + '_src')
                if cnt == 0:
                    column_compare = column_compare + 'when(df_merge.' + name + '_src!=df_merge.' + name + '_tgt, lit(\'' + name + '\'))'
                else:
                    column_compare = column_compare + '.when(df_merge.' + name + '_src!=df_merge.' + name + '_tgt, lit(\'' + name + '\'))'
                cnt = cnt + 1
            if not (name in tgt_pks):
                select_list.append(name + '_tgt')
        return pk_condition, row_ind_src_con, row_ind_tgt_con, select_list, column_compare
    except Exception as diff_pre_error:
        print(diff_pre_error)


# Join dataframes
def compare(src_suffix, tgt_suffix, src_pks, tgt_pks, compare_columns):
    try:
        for new_col in src_suffix.columns:
            src_suffix = src_suffix.withColumnRenamed(new_col, new_col.lower() + '_src')
        for new_col in tgt_suffix.columns:
            tgt_suffix = tgt_suffix.withColumnRenamed(new_col, new_col.lower() + '_tgt')
        pk_condition, row_ind_src_con, row_ind_tgt_con, select_list, column_compare = compare_pre(src_pks, tgt_pks, compare_columns)
        #print(pk_condition)
        df_merge = src_suffix.join(tgt_suffix, [eval(con) for con in pk_condition], how='outer')
        # replace PK columns
        nvl = len(src_pks)
        for cnt in range(nvl):
            re_name = 'coalesce(df_merge.' + src_pks[cnt] + '_src,df_merge.' + tgt_pks[cnt] + '_tgt)'
            df_merge = df_merge.withColumn(src_pks[cnt], eval(re_name))
        df_merge = df_merge.withColumn('row_ind', when(eval(row_ind_tgt_con), 'S').when(eval(row_ind_src_con), 'T').otherwise('B')) \
                           .withColumn('compare', array_compact(array(eval(column_compare))))
        #Row Counts
        # print(df_merge.printSchema())
        common_count = df_merge.where("row_ind == 'B'").count()
        common_match_count = df_merge.where((col('row_ind') == 'B') & (size(col('compare')) == lit(0))).count()
        common_mismatch_count = df_merge.where((col('row_ind') == 'B') & (size(col('compare')) > lit(0))).count()
        only_src_cnt = df_merge.where("row_ind == 'S'").count()
        only_tgt_cnt = df_merge.where("row_ind == 'T'").count()
        # Print row counts
        print('Row Counts:')
        print('SOURCE ONLY: {} rows'.format(only_src_cnt))
        print('TARGET ONLY: {} rows'.format(only_tgt_cnt))
        print('COMMON: {} rows'.format(common_count))
        print('COMMON COLUMNS WITH ALL MATCHING: {} rows'.format(common_match_count))
        print('COMMON COLUMNS WITH AT LEAST ONE NOT MATCHING: {} rows'.format(common_mismatch_count))
        print('')
        # Print sample rows
        if only_src_cnt > 0:
            print('ROWS ONLY IN SOURCE SAMPLE DATA:')
            df_merge.where("row_ind == 'S'").select(*select_list, 'row_ind', 'compare').show(truncate=False, n=5)
            print('')
        if only_tgt_cnt > 0:
            print('ROWS ONLY IN TARGET SAMPLE DATA:')
            df_merge.where("row_ind == 'T'").select(*select_list, 'row_ind', 'compare').show(truncate=False, n=5)
            print('')
        if common_mismatch_count > 0:
            print('COMMON COLUMNS WITH AT LEAST ONE NOT MATCHING SAMPLE DATA:')
            df_merge.where((col('row_ind') == 'B') & (size(col('compare')) > lit(0))).select(*select_list, 'row_ind', 'compare').show( truncate=False, n=5)
            print('')
        if common_match_count > 0:
            print('COMMON ROWS WITH ALL COLUMNS MATCHING SAMPLE DATA:')
            df_merge.where((col('row_ind') == 'B') & (size(col('compare')) == lit(0))).select(*select_list, 'row_ind', 'compare').show(truncate=False, n=5)
            print('')
    except Exception as diff_error:
        print(diff_error)

def datafame_desc(spark, desc_df,pks ):
    try:
        desc_table = describe_table(spark, desc_df)
        print("Table description: ")
        print(desc_table.show(truncate=False, n=1000))
        print('')
        dups_check(desc_df)
        validate_unique = input("Do you want check if PK column have duplicate (yes, no)? ").strip().lower()
        if validate_unique in ('y', 'yes'):
            validate_unique_keys(desc_df, pks)
        sample_data = input("Do you need sample data (yes, no)? ").strip().lower()
        if sample_data in ('y', 'yes'):
            print("Table Sample data: ")
            print(desc_df.show(truncate=False, n=5))
            print('')
    except Exception as desc_error:
        print(desc_error)

def main():
    #getting  configurations
    parser = ConfigParser()
    parser.read('../../auth.ini')
    spark_jars = parser.get('CONFIG', 'spark_jars')
    # The no of columns should match between src and tgt
    src_pks = ['address_gid', 'address_1', 'postal_code']
    tgt_pks = ['address_gid', 'address_1', 'postal_code']
    src_sql = "select * from address order by address_gid"
    tgt_sql = "select *,1 AS ID from address order by address_gid"

    #option to select that will call the appropriate functions
    print("""
    Choose option from below (Enter 1, 2 or 3):

    1. Describe Source Table.
    2. Describe Target Table
    3. Compare Source and Target Tables.""")
    option = input().strip()

    # Creating Spark Session
    spark = create_spark_session(SparkSession, spark_jars)
    if option == '1':
        src = read_data(spark, parser, src_sql, 'SRC')
        datafame_desc(spark, src, src_pks)

    elif option == '2':
        tgt = read_data(spark, parser, tgt_sql, 'TGT')
        datafame_desc(spark, tgt, tgt_pks)

    elif option == '3':
        src = read_data(spark, parser, src_sql, 'SRC')
        tgt = read_data(spark, parser, tgt_sql, 'TGT')

        compare_columns = schema_validation(src, tgt)
        compare(src, tgt, src_pks, tgt_pks, compare_columns)
    else:
        print('In correct option')

    spark.stop()
    #print('test')


if __name__ == "__main__":
    main()


