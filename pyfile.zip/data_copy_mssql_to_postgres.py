#Import all required libraries

import pyodbc as po
import pandas as pd
from sqlalchemy import create_engine,text as sql_text
from configparser import ConfigParser


#Create engine method
def create_conn_url(parser, db_conn_name):
    try:
        conn_string = ''
        db_type = ''
        auth_type = ''
        if parser.has_option(db_conn_name, 'type'):
            db_type = parser.get(db_conn_name, 'type')
        else:
            raise Exception("Missing database type in auth.ini file.")

        if parser.has_option(db_conn_name, 'password'):
            auth_type = 'password'
        elif db_type.lower() not in ('snow', 'snowflake'):
            auth_type = 'windows'
        else:

            raise Exception("Correct Authentication method (passowrd/windows) in auth.ini file.")

        if (auth_type == 'password') & (db_type in ('pg', 'postgres', 'postgresql', 'pgadmin', 'postgres sql')):
            conn_string = r'postgresql://{user}:{password}@{server}:{port}/{database}'.format(server=parser.get(db_conn_name, 'server'), database=parser.get(db_conn_name, 'database'), user=parser.get(db_conn_name, 'user'), password=parser.get(db_conn_name, 'password'), port=parser.get(db_conn_name, 'port'))

        elif (auth_type == 'password') & (db_type in ('ms', 'microsoft', 'ms sql server', 'mssql', 'sql server')):
            conn_string = r'mssql+pyodbc://{server}/{database}?user={user}&password={password}&driver=SQL+Server'.format(server = parser.get(db_conn_name,'server'), database=parser.get(db_conn_name,'database'), user=parser.get(db_conn_name,'user'), password = parser.get(db_conn_name,'password'))

        elif (auth_type == 'windows') & (db_type in ('ms', 'microsoft', 'ms sql server', 'mssql', 'sql server')):
            conn_string = r'mssql+pyodbc://{server}/{database}?trusted_connection=yes&driver=SQL+Server'.format(server = parser.get(db_conn_name,'server'), database=parser.get(db_conn_name,'database'))

        return conn_string, db_type
    except Exception as engine:
        print(f'Invalid Database connection name: {db_conn_name} or auth type: {auth_type}'.format(db_conn_name=db_conn_name, auth_type=auth_type))
        print(engine)


#Truncate tables
def truncate_tables(tgt_conn_eng, src_tables, target_table_suffix, tgt_schema):
    for table in src_tables:
        try:
            if target_table_suffix is None:
                tgt_table = table
            else:
                tgt_table = table+target_table_suffix
            tgt_sql_conn = tgt_conn_eng.connect()
            sql_query = sql_text('truncate table  {schema}.{table_name}'.format(schema=tgt_schema, table_name=tgt_table))
            tgt_sql_conn.execution_options(autocommit=True).execute(sql_query)
            #df = pd.read_sql_query(sql_query, tgt_conn_eng)
            print('Truncated table: {table_name}'.format(table_name=table))
        except Exception as e:
            print('Truncate process Failed for table: {table_name}'.format(table_name=table))
            print(e)


#Data load from source to target
def data_load(src_conn_eng, tgt_conn_eng, src_tables, target_table_suffix, src_schema, tgt_schema, where_condition):
    for table in src_tables:
        if table in where_condition.keys():
            sql_query = '''select * from  {schema}.{table_name} {condition}'''.format(schema=src_schema, table_name=table, condition=where_condition[table])
        else:
            sql_query = '''select * from  {schema}.{table_name}'''.format(schema=src_schema, table_name=table)
        try:
            if target_table_suffix is None:
                tgt_table = table
            else:
                tgt_table = table+target_table_suffix
            print('')
            print('Process Started for table: {table_name}'.format(table_name=table))
            total_count = 0
            for df_chunk in pd.read_sql_query(sql_query, src_conn_eng, chunksize=50000):
                df_chunk.columns = [col.lower() for col in df_chunk.columns]
                df_chunk.to_sql(tgt_table, tgt_conn_eng, index=False, if_exists='append', schema=tgt_schema)
                total_count = total_count + len(df_chunk)
            #print(total_count)
            print('Process Completed for table: {table_name} and loaded {rows} records'.format(table_name=table, rows=total_count))
            print('')
        except Exception as e:
            print('Process Failed for table: {table_name}'.format(table_name=table))
            print(e)


#Remove extra characters and convert to lower case
def lower_case(input_value):
    if isinstance(input_value, str):
        input_value = input_value.strip().lower()

    if isinstance(input_value, list):
        input_value = [name.strip().lower() for name in input_value]
    return input_value


def upper_case(input_value):
    if isinstance(input_value, str):
        input_value = input_value.strip().upper()
    return input_value


def main():
    try:
        # Read credentials from config file
        parser = ConfigParser()
        parser.read('auth.ini')
    except Exception as config_issue:
        print('Process failed while reading auth.ini file: ', config_issue)

    try:
        src_conn_name = input('Please Enter Source Database connection name from auth.ini file:')
        src_conn_name = upper_case(src_conn_name)

        tgt_conn_name = input('Please Enter Target Database connection name from auth.ini file:')
        tgt_conn_name = upper_case(tgt_conn_name)

        src_conn, src_db_type = create_conn_url(parser, src_conn_name)
        tgt_conn, tgt_db_type = create_conn_url(parser, tgt_conn_name)
        try:
            if (src_conn is None) | (tgt_conn is None):
                raise Exception('Invalid Source or Target connection...Please check connection info and run again.')
            # Create engine
            src_conn_eng = create_engine(src_conn)
            tgt_conn_eng = create_engine(tgt_conn)

        except Exception as conn_creation_fail:
            print('Failed while creating connection engine: ')
            raise Exception(conn_creation_fail)

        #Collect the schema and table names
        #src_schema = input('Please enter the source schema name:')
        src_schema = 'dbo'
        src_table_names = input('Please enter the source table names with comma (,) separated:').split(',')
        src_table_names, src_schema = lower_case(src_table_names), lower_case(src_schema)
        ##tgt_schema = input('Please enter the target schema name:')
        tgt_schema = 'data'
        tgt_schema = lower_case(tgt_schema)
        target_table_suffix = input('Please enter the target table suffix name (leave blank if you want same as source table name:')
        #target_table_suffix = None
        if ~ (target_table_suffix is None):
            target_table_suffix = target_table_suffix.strip()
        where_condition = {}

        #truncate = input("Do you want to truncate target tables(y/n)? ")
        #truncate = lower_case(truncate)
        #Truncate tables
        #if truncate in ('y', 'yes'):
        #    truncate_tables(tgt_conn_eng, src_table_names, target_table_suffix, tgt_schema)
        #Calling data load method
        data_load(src_conn_eng, tgt_conn_eng, src_table_names, target_table_suffix, src_schema, tgt_schema, where_condition)


    except Exception as whole:
        print('Process failed with error: ', whole)


if __name__ == "__main__":
    main()
